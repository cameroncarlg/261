//Cameron Guilbeau
//c00251326
//Program Description: This program is designed to create 7 recursive methods.
//Certificate of Authenticity: I certify that the code in the method functions including method function main of
//this project are entirely my own work.

package com.company;

import java.lang.reflect.Array;
import java.util.Scanner;
import static java.lang.Math.min;

public class Main {

    //SUM
    //
    //This method will take in an input "n" and return the sum from 1 to n.
    //Pre: the number is passed into the function, where it is checked if it is equal to one
    //Post: If the number passed to the function is not equal to one, the function will try to calculate what
    //the function with n-1 + n is. The function does not know what n-1 is and must call itself and add a stack
    //to come back to once it figures out n-1, once the base case has been reached, the program will go through all
    //the stacks adding n to them.
    public static int sum (int n){
        return n==1 ? 1 : sum(n-1) + n;
    }

    //GCD
    //
    //This method first assumes m > n, then denotes the greatest common divisor for the two.
    //Pre: The method takes the two inputs, and first checks to see if m can be divided by n evenly. If it can, n is
    // our greatest common factor.
    //Post: If not, the function will call itself until a common divisor is found.
    public static int gcd (int m, int n){
        return m%n==0 ? n : gcd (n, m%n);
    }

    //BINARY
    //
    //This method takes an integer in and converts it into a binary value.
    //Pre: First we initialize a variable a to store as our remainder value. We make sure that our value is greater
    //than 0 and store the remainder of n%2 into a.
    //Post: The method then calls itself and this time divides n by 2, tacking a onto our result, giving us a
    //string of remainders, resulting in our binary integer.
    public static String binary (int n){
        int a;
        if (n>0){
            a = n % 2;
            return binary(n/2) + "" + a;
        }
        return "";
    }

    //HARMONIC
    //
    //This method will take in an integer, and recursively calculates and returns the nth harmonic number.
    //Pre: First we take the reciprocal of n and store that into a. We then check to see if n is equal to 1, if so
    //we return 1.
    //Post: If it is not, we will call the function again and subtract 1 from n and add our current a value. The function
    //will then turn that n-1 into the reciprocal and repeat.
    public static double harmonic (int n){
        double a = 1.0/n;
        if (n==1){
            return 1;
        }
        else{
            return harmonic(n-1) + a;
        }
    }

    //SERIES
    //
    //This method will calculates the given series.
    //Pre: Similar to harmonic, this function first turns our integer value into the form we need given by the problem.
    //The function the checks to see if our n value equals 1. If that is true, we return 1/3.
    //Post: Until this is true, we call the function again, subtracting 1 from n and adding our current a value.
    public static double series (int n){
        double a = n/((2.0*n)+1);
        if (n==1){
            return (1.0/3);
        }
        else {
            return series(n-1) + a;
        }
    }

    //LARGEST ELEMENT
    //
    //This is a recursive method that returns the largest integer in an array of user input.
    //Pre:
    public static int LargestElement (int[] a, int n){
        if (n==1){
            return a[0];
        } else {
            return Math.max(a[n-1], LargestElement(a, n-1));
        }
    }

    //ODDEVENFACT
    //
    //This method recursively calculates the odd/even factorial value of the given integer.
    //Pre: First we check that our value is not equal to 1 or 0, if it is, we return 1.
    //Post: If not, the function calls itself subtracting 2 from n and multiplying the current n value.
    public static long oddevenfact (int n){
        if (n==0 || n==1){
            return 1;
        } else {
            return oddevenfact(n -2) * n;
        }
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Please enter a number: ");
        int number = input.nextInt();
        System.out.println(sum(number));

        System.out.print("Please enter two numbers: ");
        int number2 = input.nextInt();
        int number3 = input.nextInt();
        System.out.println(gcd(number2, number3));

        System.out.print("Please enter a number to be converted to binary: ");
        int number4 = input.nextInt();
        System.out.println(binary(number4));

        System.out.print("Please enter your harmonic number: ");
        int number5 = input.nextInt();
        System.out.println(harmonic(number5));

        System.out.print("Please enter a number for the series: ");
        int number6 = input.nextInt();
        System.out.println(series(number6));

        System.out.print("Please enter eight integers to fill an array with: ");
        int[] number7 = new int[8];
        for (int i=0; i<number7.length; i++){
            int num = input.nextInt();
            number7[i] = num;
        }
        System.out.println(LargestElement(number7, number7.length));

        System.out.print("Please enter a positive integer: ");
        int number8 = input.nextInt();
        System.out.println(oddevenfact(number8));



















    }
}
