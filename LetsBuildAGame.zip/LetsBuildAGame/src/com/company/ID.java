package com.company;

public enum ID {
    Player(),
    BasicEnemy();
}
