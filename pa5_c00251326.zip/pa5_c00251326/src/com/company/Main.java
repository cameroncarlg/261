// Cameron Guilbeau
// c00251326
// CMPS 260
// Programming Assignment : #5
// Due Date : 2/15/2020
// Program Description:  (a brief description of actions of your code)
// Certificate of Authenticity: I certify that, other than the code provided by
// the instructor, the code in this project is entirely my own work.

package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
    }
}
