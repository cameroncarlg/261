// Cameron Guilbeau
// c00251326
// CMPS 260
// Programming Assignment : #5
// Due Date : 2/15/2020
// Program Description:  (a brief description of actions of your code)
// Certificate of Authenticity: I certify that, other than the code provided by
// the instructor, the code in this project is entirely my own work.

package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Please enter the amount of plants in your garden: ");
        int max = input.nextInt();

        Garden garden1 = new Garden(max);
        System.out.println();
        System.out.println("#1, Show number of plants in the garden: ");
        System.out.println("#2, Add a plant to the garden by getting its name and height from the user: ");
        System.out.println("#3, add a plant to the garden by giving a pre-defined object: ");
        System.out.println("#4, increase the number of days since the garden has been watered by one: ");
        System.out.println("#5, water the garden if at least one plant needs water: ");
        System.out.println("#6, show the information about a specific plant in the garden: ");
        System.out.println("#7, show the information about all plants in the garden: ");
        System.out.println("#8, halt the application: ");
        System.out.print("Please select your option: ");
        int selection = input.nextInt();
        do {
            if (selection == 1) {
                System.out.print("Number of plants in garden is: " + garden1.getNumPlants());
                System.out.println();
            } else if (selection == 2) {
                System.out.print("Enter the name of your plant: ");
                String name = input.next();
                System.out.print("Enter the height of your plant: ");
                Double height = input.nextDouble();
                garden1.addPlant2(name, height);
                System.out.println();

            } else if (selection == 3) {
                System.out.println("Would you like to add a flower, shrub, or tree to your garden?");
                System.out.println("Press 1 for flower");
                System.out.println("Press 2 for shrub");
                System.out.println("Press 3 for tree");
                int choice = input.nextInt();
                if (choice == 1){
                    Plant a = Plant.createFlower();
                    garden1.addPlant1(a);
                }
                else if (choice == 2){
                    Plant b = Plant.createShrub();
                    garden1.addPlant1(b);
                }
                else if (choice == 3) {
                    Plant c = Plant.createTree();
                    garden1.addPlant1(c);
                }

            } else if (selection == 4) {
                garden1.setDaysSinceWatered(1);
                System.out.println();
            } else if (selection == 5) {
                System.out.print("Enter plant position: ");
                int posnum = input.nextInt();
                garden1.getPlant(posnum);
            }
            System.out.println();
            System.out.println("#1, Show number of plants in the garden: ");
            System.out.println("#2, Add a plant to the garden by getting its name and height from the user: ");
            System.out.println("#3, add a plant to the garden by giving a pre-defined object: ");
            System.out.println("#4, increase the number of days since the garden has been watered by one: ");
            System.out.println("#5, water the garden if at least one plant needs water: ");
            System.out.println("#6, show the information about a specific plant in the garden: ");
            System.out.println("#7, show the information about all plants in the garden: ");
            System.out.println("#8, halt the application: ");
            System.out.print("Please select your option: ");
            selection = input.nextInt();

        } while (selection != -1);

    }
}
