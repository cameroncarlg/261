package com.company;

public class Garden {

    private Plant[] garden1;
    private int numOfPlants;
    private int daysSinceWatered = 0;

    public Garden(int g) {
        if (g >= 3)
            garden1 = new Plant[g];
        else
            garden1 = new Plant[3];
    }

    public Garden() {
        garden1 = new Plant[3];
    }

    public int getNumPlants() {
        return numOfPlants;
    }

    public int getDaysSinceWatered() {
        return daysSinceWatered;
    }

    public void setDaysSinceWatered(int n) {
        if (n > 0)
            daysSinceWatered += n;
    }

    public void addPlant1(Plant a) {
        if (numOfPlants < garden1.length){
            garden1[numOfPlants] = new Plant();
            numOfPlants++;
        }
    }

    public void addPlant2(String s, double h){
        if (numOfPlants < garden1.length){
            garden1[numOfPlants] = new Plant(s, h);
            numOfPlants++;
        }
    }

    public String getPlant(int n){
        return garden1[n].toString();
    }




}
