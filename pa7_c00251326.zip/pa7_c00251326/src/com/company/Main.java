// Cameron Guilbeau
// c00251326
// CMPS 260
// Programming Assignment : #7
// Due Date : 4/24/2020
// Program Description:
// Certificate of Authenticity: I certify that, other than the code provided by the
// instructor, the code in this project is entirely my own work.

package com.company;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void readList(File f, ArrayList<newitems> inventory) {

        try (Scanner filereader = new Scanner(f)) {

            while (filereader.hasNext()) {
                int x = filereader.nextInt();
                int y = filereader.nextInt();
                String z = filereader.next();

                newitems l1 = new newitems(x, y, z);

                inventory.add(l1);
            }

        } catch (Exception e) {
            System.out.println("File input error");
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        File f = new File("Groceries.txt");

        ArrayList<newitems> inventory = new ArrayList();
        ArrayList<newitems> cart = new ArrayList<>();
        newitems l2 = new newitems();
        cart.add(l2);
        readList(f, inventory);
        int carteggs = 0;
        int cartbread = 0;
        int cartbutter = 0;
        int cartcheese = 0;
        int cartmilk = 0;


        //System.out.println(inventory);

        System.out.println("Hello, welcome to the store!");
        System.out.println("1. select an item from the inventory to place in your shopping cart");
        System.out.println("2. take an item out of the cart and return it to the inventory");
        System.out.println("3. check out");
        System.out.println("4. Quit");
        System.out.print("Please select your option: ");
        int selection = input.nextInt();
        System.out.println();

        do {
            if (selection == 1) {

                System.out.println("Here's what our inventory consists of: ");
                System.out.println("Item #1:" + inventory.get(0).getName() + "    Quantity:" + inventory.get(0).getQuantity() + "  Price:" + inventory.get(0).getPrice());
                System.out.println("Item #2:" + inventory.get(1).getName() + "   Quantity:" + inventory.get(1).getQuantity() + "  Price:" + inventory.get(1).getPrice());
                System.out.println("Item #3:" + inventory.get(2).getName() + "  Quantity:" + inventory.get(2).getQuantity() + "  Price:" + inventory.get(2).getPrice());
                System.out.println("Item #4:" + inventory.get(3).getName() + "  Quantity:" + inventory.get(3).getQuantity() + "  Price:" + inventory.get(3).getPrice());
                System.out.println("Item #5:" + inventory.get(4).getName() + "    Quantity:" + inventory.get(4).getQuantity() + "  Price:" + inventory.get(4).getPrice());
                System.out.println("6. Choose no item");
                System.out.print("Select your item: ");
                int selection2 = input.nextInt();

                do {
                    if (selection2 == 1) {
                        int newquant = inventory.get(0).getQuantity() - 1;
                        inventory.get(0).setQuantity(newquant);
                        carteggs++;
                        newitems c1 = new newitems(carteggs, inventory.get(0).getPrice(), inventory.get(0).getName());
                        cart.add(c1);
                        System.out.println(cart);
                        System.out.println("Here's what our inventory consists of: ");
                        System.out.println("Item #1:" + inventory.get(0).getName() + "    Quantity:" + inventory.get(0).getQuantity() + "  Price:" + inventory.get(0).getPrice());
                        System.out.println("Item #2:" + inventory.get(1).getName() + "   Quantity:" + inventory.get(1).getQuantity() + "  Price:" + inventory.get(1).getPrice());
                        System.out.println("Item #3:" + inventory.get(2).getName() + "  Quantity:" + inventory.get(2).getQuantity() + "  Price:" + inventory.get(2).getPrice());
                        System.out.println("Item #4:" + inventory.get(3).getName() + "  Quantity:" + inventory.get(3).getQuantity() + "  Price:" + inventory.get(3).getPrice());
                        System.out.println("Item #5:" + inventory.get(4).getName() + "    Quantity:" + inventory.get(4).getQuantity() + "  Price:" + inventory.get(4).getPrice());
                        System.out.println("6. Choose no item");
                        System.out.print("Select your item: ");
                        selection2 = input.nextInt();
                    } else if (selection2 == 2) {
                        cartbread++;
                        int newquant = inventory.get(1).getQuantity() - 1;
                        cart.get(0).setQuantity(cartbread);
                        inventory.get(1).setQuantity(newquant);
                        //cart.get(0).setQuantity(1);
                        cart.get(0).setPrice(inventory.get(0).getPrice());
                        cart.get(0).setName("bread");
                        System.out.println(cart);
                        System.out.println("Here's what our inventory consists of: ");
                        System.out.println("Item #1:" + inventory.get(0).getName() + "    Quantity:" + inventory.get(0).getQuantity() + "  Price:" + inventory.get(0).getPrice());
                        System.out.println("Item #2:" + inventory.get(1).getName() + "   Quantity:" + inventory.get(1).getQuantity() + "  Price:" + inventory.get(1).getPrice());
                        System.out.println("Item #3:" + inventory.get(2).getName() + "  Quantity:" + inventory.get(2).getQuantity() + "  Price:" + inventory.get(2).getPrice());
                        System.out.println("Item #4:" + inventory.get(3).getName() + "  Quantity:" + inventory.get(3).getQuantity() + "  Price:" + inventory.get(3).getPrice());
                        System.out.println("Item #5:" + inventory.get(4).getName() + "    Quantity:" + inventory.get(4).getQuantity() + "  Price:" + inventory.get(4).getPrice());
                        System.out.println("6. Choose no item");
                        System.out.print("Select your item: ");
                        selection2 = input.nextInt();
                    } else if (selection2 == 3) {
                        cartbutter++;
                        int newquant = inventory.get(2).getQuantity() - 1;
                        cart.get(0).setQuantity(cartbutter);
                        inventory.get(2).setQuantity(newquant);
                        //cart.get(0).setQuantity(1);
                        cart.get(0).setPrice(inventory.get(0).getPrice());
                        cart.get(0).setName("butter");
                        System.out.println(cart);
                        System.out.println("Here's what our inventory consists of: ");
                        System.out.println("Item #1:" + inventory.get(0).getName() + "    Quantity:" + inventory.get(0).getQuantity() + "  Price:" + inventory.get(0).getPrice());
                        System.out.println("Item #2:" + inventory.get(1).getName() + "   Quantity:" + inventory.get(1).getQuantity() + "  Price:" + inventory.get(1).getPrice());
                        System.out.println("Item #3:" + inventory.get(2).getName() + "  Quantity:" + inventory.get(2).getQuantity() + "  Price:" + inventory.get(2).getPrice());
                        System.out.println("Item #4:" + inventory.get(3).getName() + "  Quantity:" + inventory.get(3).getQuantity() + "  Price:" + inventory.get(3).getPrice());
                        System.out.println("Item #5:" + inventory.get(4).getName() + "    Quantity:" + inventory.get(4).getQuantity() + "  Price:" + inventory.get(4).getPrice());
                        System.out.println("6. Choose no item");
                        System.out.print("Select your item: ");
                        selection2 = input.nextInt();
                    } else if (selection2 == 4) {
                        int cheese;
                        int newquant = inventory.get(3).getQuantity() - 1;
                        cart.get(0).setQuantity(cartcheese);
                        inventory.get(3).setQuantity(newquant);
                        //cart.get(0).setQuantity(1);
                        cart.get(0).setPrice(inventory.get(0).getPrice());
                        cart.get(0).setName("cheese");
                        System.out.println(cart);
                        System.out.println("Here's what our inventory consists of: ");
                        System.out.println("Item #1:" + inventory.get(0).getName() + "    Quantity:" + inventory.get(0).getQuantity() + "  Price:" + inventory.get(0).getPrice());
                        System.out.println("Item #2:" + inventory.get(1).getName() + "   Quantity:" + inventory.get(1).getQuantity() + "  Price:" + inventory.get(1).getPrice());
                        System.out.println("Item #3:" + inventory.get(2).getName() + "  Quantity:" + inventory.get(2).getQuantity() + "  Price:" + inventory.get(2).getPrice());
                        System.out.println("Item #4:" + inventory.get(3).getName() + "  Quantity:" + inventory.get(3).getQuantity() + "  Price:" + inventory.get(3).getPrice());
                        System.out.println("Item #5:" + inventory.get(4).getName() + "    Quantity:" + inventory.get(4).getQuantity() + "  Price:" + inventory.get(4).getPrice());
                        System.out.println("6. Choose no item");
                        System.out.print("Select your item: ");
                        selection2 = input.nextInt();
                    } else if (selection2 == 5) {
                        cartmilk++;
                        int newquant = inventory.get(4).getQuantity() - 1;
                        cart.get(0).setQuantity(cartmilk);
                        inventory.get(4).setQuantity(newquant);
                        //cart.get(0).setQuantity(1);
                        cart.get(0).setPrice(inventory.get(0).getPrice());
                        cart.get(0).setName("milk");
                        System.out.println(cart);
                        System.out.println("Here's what our inventory consists of: ");
                        System.out.println("Item #1:" + inventory.get(0).getName() + "    Quantity:" + inventory.get(0).getQuantity() + "  Price:" + inventory.get(0).getPrice());
                        System.out.println("Item #2:" + inventory.get(1).getName() + "   Quantity:" + inventory.get(1).getQuantity() + "  Price:" + inventory.get(1).getPrice());
                        System.out.println("Item #3:" + inventory.get(2).getName() + "  Quantity:" + inventory.get(2).getQuantity() + "  Price:" + inventory.get(2).getPrice());
                        System.out.println("Item #4:" + inventory.get(3).getName() + "  Quantity:" + inventory.get(3).getQuantity() + "  Price:" + inventory.get(3).getPrice());
                        System.out.println("Item #5:" + inventory.get(4).getName() + "    Quantity:" + inventory.get(4).getQuantity() + "  Price:" + inventory.get(4).getPrice());
                        System.out.println("6. Choose no item");
                        System.out.print("Select your item: ");
                        selection2 = input.nextInt();
                    }
                } while (selection2 != 6);

            }
            if (selection == 2) {
                System.out.println("What item will you be removing");
                System.out.println(cart);

            }

            System.out.println("Hello, welcome to the store!");
            System.out.println("1. select an item from the inventory to place in your shopping cart");
            System.out.println("2. take an item out of the cart and return it to the inventory");
            System.out.println("3. check out");
            System.out.println("4. Quit");
            System.out.print("Please select your option: ");
            selection = input.nextInt();

        } while (selection != 4);

    }
}

