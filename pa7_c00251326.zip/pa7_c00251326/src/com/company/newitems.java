package com.company;

public class newitems extends Main {

    private int quantity;
    private int price;
    private String name;

    public newitems() {

    }

    public newitems(int q, int p, String n) {
        setQuantity(q);
        setPrice(p);
        setName(n);
    }

    public int getQuantity() {
        return this.quantity;
    }

    public void setQuantity(int p) {
        if (p >= 0) {
            this.quantity = p;
        }
    }

    public int getPrice() {
        return this.price;
    }

    public void setPrice(int p) {
        if (p > 0) {
            this.price = p;
        }
    }

    public String getName() {
        return this.name;
    }

    public void setName(String n) {
        if (n != null) {
            this.name = n;
        }
    }

    public String toString() {
        return "(" + quantity + "," + price + ", " + name + ")";
    }


}
